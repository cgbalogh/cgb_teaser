<?php
namespace CGB\CgbTeaser\Tests\Unit\Domain\Model;

/**
 * Test case.
 */
class PageTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \CGB\CgbTeaser\Domain\Model\Page
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \CGB\CgbTeaser\Domain\Model\Page();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getTeaserimageReturnsInitialValueForFileReference()
    {
        self::assertEquals(
            null,
            $this->subject->getTeaserimage()
        );
    }

    /**
     * @test
     */
    public function setTeaserimageForFileReferenceSetsTeaserimage()
    {
        $fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
        $this->subject->setTeaserimage($fileReferenceFixture);

        self::assertAttributeEquals(
            $fileReferenceFixture,
            'teaserimage',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTeasertextReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTeasertext()
        );
    }

    /**
     * @test
     */
    public function setTeasertextForStringSetsTeasertext()
    {
        $this->subject->setTeasertext('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'teasertext',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTextonlyReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getTextonly()
        );
    }

    /**
     * @test
     */
    public function setTextonlyForBoolSetsTextonly()
    {
        $this->subject->setTextonly(true);

        self::assertAttributeEquals(
            true,
            'textonly',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getTeasertypeReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getTeasertype()
        );
    }

    /**
     * @test
     */
    public function setTeasertypeForIntSetsTeasertype()
    {
        $this->subject->setTeasertype(12);

        self::assertAttributeEquals(
            12,
            'teasertype',
            $this->subject
        );
    }
}
