<?php
namespace CGB\CgbTeaser\Domain\Model;

/***
 *
 * This file is part of the "CGB Teaser" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018
 *
 ***/

/**
 * Content
 */
class Content extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * Show Page
     *
     * @var string
     */
    protected $showpage = '';

    /**
     * Mode
     *
     * @var int
     */
    protected $mode = 0;

    /**
     * Returns the showpage
     *
     * @return string $showpage
     */
    public function getShowpage()
    {
        return $this->showpage;
    }

    /**
     * Sets the showpage
     *
     * @param string $showpage
     * @return void
     */
    public function setShowpage($showpage)
    {
        $this->showpage = $showpage;
    }

    /**
     * Returns the mode
     *
     * @return int $mode
     */
    public function getMode()
    {
        return $this->mode;
    }

    /**
     * Sets the mode
     *
     * @param int $mode
     * @return void
     */
    public function setMode($mode)
    {
        $this->mode = $mode;
    }
}
