<?php
namespace CGB\CgbTeaser\Domain\Model;

/***
 *
 * This file is part of the "CGB Teaser" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018
 *
 ***/

/**
 * Page
 */
class Page extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * Teaser Image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $teaserimage = null;

    /**
     * Teaser Text
     *
     * @var string
     */
    protected $teasertext = '';

    /**
     * Text Only
     *
     * @var bool
     */
    protected $textonly = false;

    /**
     * Teaser Type
     *
     * @var int
     */
    protected $teasertype = 0;

    /**
     * Returns the teaserimage
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $teaserimage
     */
    public function getTeaserimage()
    {
        return $this->teaserimage;
    }

    /**
     * Sets the teaserimage
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $teaserimage
     * @return void
     */
    public function setTeaserimage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $teaserimage)
    {
        $this->teaserimage = $teaserimage;
    }

    /**
     * Returns the teasertext
     *
     * @return string $teasertext
     */
    public function getTeasertext()
    {
        return $this->teasertext;
    }

    /**
     * Sets the teasertext
     *
     * @param string $teasertext
     * @return void
     */
    public function setTeasertext($teasertext)
    {
        $this->teasertext = $teasertext;
    }

    /**
     * Returns the textonly
     *
     * @return bool $textonly
     */
    public function getTextonly()
    {
        return $this->textonly;
    }

    /**
     * Sets the textonly
     *
     * @param bool $textonly
     * @return void
     */
    public function setTextonly($textonly)
    {
        $this->textonly = $textonly;
    }

    /**
     * Returns the boolean state of textonly
     *
     * @return bool
     */
    public function isTextonly()
    {
        return $this->textonly;
    }

    /**
     * Returns the teasertype
     *
     * @return int $teasertype
     */
    public function getTeasertype()
    {
        return $this->teasertype;
    }

    /**
     * Sets the teasertype
     *
     * @param int $teasertype
     * @return void
     */
    public function setTeasertype($teasertype)
    {
        $this->teasertype = $teasertype;
    }
}
