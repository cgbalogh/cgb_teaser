<?php
namespace CGB\CgbTeaser\Tests\Unit\Domain\Model;

/**
 * Test case.
 */
class ContentTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \CGB\CgbTeaser\Domain\Model\Content
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \CGB\CgbTeaser\Domain\Model\Content();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getShowpageReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getShowpage()
        );
    }

    /**
     * @test
     */
    public function setShowpageForStringSetsShowpage()
    {
        $this->subject->setShowpage('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'showpage',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getModeReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getMode()
        );
    }

    /**
     * @test
     */
    public function setModeForIntSetsMode()
    {
        $this->subject->setMode(12);

        self::assertAttributeEquals(
            12,
            'mode',
            $this->subject
        );
    }
}
